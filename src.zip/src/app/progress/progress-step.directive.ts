import { Directive } from '@angular/core';

@Directive({
  selector: '[appProgressStep]'
})
export class ProgressStepDirective {

  constructor() { }

}
