import { ProgressStepDirective } from './progress-step.directive';

describe('ProgressStepDirective', () => {
  it('should create an instance', () => {
    const directive = new ProgressStepDirective();
    expect(directive).toBeTruthy();
  });
});
