export class illness {
    illGroup: string
    illName: string
    illAge: string

    constructor(
        illGroup: string,
        illName: string,
        illAge: string,
      ) {
        this.illGroup=illGroup,
        this.illName=illName,
        this.illAge=illAge
      }
  }
  